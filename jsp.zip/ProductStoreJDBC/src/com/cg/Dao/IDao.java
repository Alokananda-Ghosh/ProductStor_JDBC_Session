package com.cg.Dao;

import java.util.HashMap;

import com.cg.bean.Product;
import com.cg.exception.ProductException;

public interface IDao 
{
	//public int setProduct(int pid,Product p) throws ProductException;
	
	public HashMap<Integer, Product> getAll() throws ProductException;
	int addProduct(Product p) throws ProductException;
}
