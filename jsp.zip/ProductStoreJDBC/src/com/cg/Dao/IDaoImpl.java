package com.cg.Dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import com.cg.bean.Product;
import com.cg.exception.ProductException;
import com.cg.util.CollectionUtil;
import com.cg.util.ConnectionFactory;


public class IDaoImpl implements IDao 
{
	Connection con=null;
	PreparedStatement ps=null;
	ResultSet rs=null;

	@Override
	public int addProduct(Product p) throws ProductException  {
		int id=0;
		// TODO Auto-generated method stub
		try {
			con=ConnectionFactory.getSigntonObj().getConnection();
			if(con==null) {
				throw new ProductException("connection not established");
			}
				ps=con.prepareStatement(QueryMapping.INSERT_QUERY);
			    
				ps.setString(1,p.getProductcategory());
				ps.setString(2,p.getProductname());
				ps.setInt(3,p.getProductprice());
				ps.setInt(4,p.getProductquantity());
				ps.executeUpdate();
			
				
				ps=con.prepareStatement(QueryMapping.SEQ_QUERY);
				rs=ps.executeQuery();
				rs.next();
				id=rs.getInt(1);
			
		}catch(Exception ex)
		    {
				throw new ProductException("problem message"+ex.getMessage());
				
	        }
		    finally 
		    {
		    	try {
		    	if(con==null||ps==null)
		    	{
		    		throw new ProductException("connection not established");
		    		
		    	}
		    	con.close();
		    	ps.close();
		    	rs.close();
		    	
		    	}
		    	catch(SQLException e)
		    	{
		    		throw new ProductException("problem in database"+e.getMessage());
		    	}
		    	catch(Exception e)
		    	{
		    		throw new ProductException("problem in database"+e.getMessage());
		    	}
		    }
		
		return id;
	}

	

	@Override
	public HashMap<Integer,Product> getAll() throws ProductException
	{
		// TODO Auto-generated method stub
		
		try {
		
			con=ConnectionFactory.getSigntonObj().getConnection();
			if(con==null) {
				throw new ProductException("connection not established");
			}
				ps=con.prepareStatement(QueryMapping.RETRIEVE_QUERY);
			rs=ps.executeQuery();
				while(rs.next())
				{
					Product p=new Product();
				p.setProductid((rs.getInt(1)));
				p.setProductcategory((rs.getString(2)));
				p.setProductname((rs.getString(3)));
				p.setProductprice((rs.getInt(4)));
				p.setProductquantity((rs.getInt(5)));
				CollectionUtil.setProducts(p);
				}
				
				
				/*ps=con.prepareStatement(QueryMapping.RETRIEVE_QUERY);
				ps.setInt(1, p.getProductid());
				rs=ps.executeQuery();
				rs.next();
				int productid=rs.getInt(1);*/
				
			}catch(Exception ex)
		    {
				throw new ProductException("problem message"+ex.getMessage());
	        }
		    finally 
		    {
		    	try {
		    	if(con==null||ps==null||rs==null)
		    	{
		    		throw new ProductException("connection not establioshed");
		    		
		    	}
		    	con.close();
		    	ps.close();
		    	rs.close();
		    	
		    	}
		    	catch(SQLException e)
		    	{
		    		throw new ProductException("problem in database"+e.getMessage());
		    	}
		    	catch(Exception e)
		    	{
		    		throw new ProductException("problem in database"+e.getMessage());
		    	}
		    }
		return  CollectionUtil.getProducts();
	
	

	
	}
	

}