package com.cg.service;

import java.util.HashMap;

import com.cg.bean.Product;
import com.cg.exception.ProductException;

public interface IService 
{
public int addProduct(Product p) throws ProductException;

public HashMap<Integer,Product> getAll() throws ProductException;
}
