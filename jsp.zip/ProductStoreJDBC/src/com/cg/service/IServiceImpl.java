package com.cg.service;

import java.util.HashMap;

import com.cg.Dao.IDao;
import com.cg.Dao.IDaoImpl;
import com.cg.bean.Product;
import com.cg.exception.ProductException;

public class IServiceImpl implements IService{
IDao dp=new IDaoImpl();

@Override
public 	int addProduct(Product p) throws ProductException {
	// TODO Auto-generated method stub
	return dp.addProduct(p);
}

@Override
public HashMap<Integer,Product> getAll() throws ProductException {
	// TODO Auto-generated method stub
	return dp.getAll();
}


	
}
