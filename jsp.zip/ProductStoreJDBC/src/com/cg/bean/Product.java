package com.cg.bean;

public class Product {
private int productid;
private String productcategory;
private String productname;
private int productprice;
private int productquantity;
public int getProductid() {
	return productid;
}
public void setProductid(int productid) {
	this.productid = productid;
}
public String getProductcategory() {
	return productcategory;
}
public void setProductcategory(String productcategory) {
	this.productcategory = productcategory;
}
public String getProductname() {
	return productname;
}
public void setProductname(String productname) {
	this.productname = productname;
}
public int getProductprice() {
	return productprice;
}
public void setProductprice(int productprice) {
	this.productprice = productprice;
}
public int getProductquantity() {
	return productquantity;
}
public void setProductquantity(int productquantity) {
	this.productquantity = productquantity;
}
@Override
public String toString() {
	return "Product [productid=" + productid + ", productcategory=" + productcategory + ", productname=" + productname
			+ ", productprice=" + productprice + ", productquantity=" + productquantity + "]";
}

}
